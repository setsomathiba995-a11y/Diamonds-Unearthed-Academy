// Initialize On-Scroll Animations
AOS.init({
    duration: 1000,
    once: true,
    offset: 100
});

// Sticky Navbar Logic
window.addEventListener('scroll', function() {
    const nav = document.querySelector('.navbar');
    if (window.scrollY > 50) {
        nav.style.padding = '12px 0';
        nav.style.background = 'rgba(5, 10, 24, 0.98)';
    } else {
        nav.style.padding = '20px 0';
        nav.style.background = 'rgba(5, 10, 24, 0.9)';
    }
});

// Form Submission Handling
const enrollmentForm = document.getElementById('enrollmentForm');
const thankYouMessage = document.getElementById('thankYouMessage');

if (enrollmentForm) {
    enrollmentForm.addEventListener('submit', function(e) {
        e.preventDefault();
        
        // Hide form and show thank you message
        enrollmentForm.style.display = 'none';
        thankYouMessage.classList.remove('hidden');
        
        // Optional: Scroll to top of the form area
        document.getElementById('enroll').scrollIntoView({ behavior: 'smooth' });
        
        // In a real production environment, you would use Fetch/AJAX here
        // to send the data to a backend service.
    });
}

// Smooth Scrolling for Nav Links
document.querySelectorAll('a[href^="#"]').forEach(anchor => {
    anchor.addEventListener('click', function (e) {
        e.preventDefault();
        document.querySelector(this.getAttribute('href')).scrollIntoView({
            behavior: 'smooth'
        });
    });
});document.getElementById("enrollmentForm").addEventListener("submit", function(e) {
    e.preventDefault();

    let student = document.getElementById("studentName").value;
    let parent = document.getElementById("parentName").value;
    let phone = document.getElementById("phone").value;
    let grade = document.getElementById("grade").value;
    let subject = document.getElementById("subject").value;

    let message =
        "New Student Registration%0A%0A" +
        "Student Name: " + student + "%0A" +
        "Parent Name: " + parent + "%0A" +
        "Phone: " + phone + "%0A" +
        "Grade: " + grade + "%0A" +
        "Subject: " + subject;

    window.open(
        "https://wa.me/26772589896?text=" + message,
        "_blank"
    );
});