# Diamonds Unearthed Academy

A Pen created on CodePen.

Original URL: [https://codepen.io/Setso-Mathiba/pen/ogBYEZE](https://codepen.io/Setso-Mathiba/pen/ogBYEZE).

Your Child Comes First